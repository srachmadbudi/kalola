<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
	<meta name="description" content="KALOLA ERP">
	<meta name="author" content="">
    
    <?php echo $__env->yieldContent('title'); ?>

	<link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/simple-line-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/select2.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/select2-bootstrap4.css')); ?>">
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.js')); ?>"></script>
</head>
<body class="app header-fixed sidebar-fixed aside-menu-fixed sidebar-lg-show">
    <?php echo $__env->make('layouts.module.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="app-body" id="dw">
        <div class="sidebar">
            <?php echo $__env->make('layouts.module.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <button class="sidebar-minimizer brand-minimizer" type="button"></button>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer class="app-footer">
        <div>
            Copyright &copy;<script>document.write(new Date().getFullYear());</script>
        </div>
        <div class="ml-auto">
            <span>Powered by</span>
            <a href="https://coreui.io">CoreUI</a>
        </div>
    </footer>
    
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pace.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/coreui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom-tooltips.min.js')); ?>"></script>
    
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\kalola2\resources\views/layouts/main.blade.php ENDPATH**/ ?>