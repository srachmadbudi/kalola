

<?php $__env->startSection('title'); ?>
    <title>Dashboard</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Home</li>
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>
    <div class="container-fluid">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Laporan Hari Ini</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="callout callout-info">
                                        <small class="text-muted">Produk Terjual</small>
                                        <br>
                                        <strong class="h4"><?php echo e($daily->sold ?? ''); ?></strong>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="callout callout-success">
                                        <small class="text-muted">Pemasukan</small>
                                        <br>
                                        <strong class="h4"><?php echo e($daily->income ?? ''); ?></strong>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="callout callout-primary">
                                        <small class="text-muted">Transaksi</small>
                                        <br>
                                        <strong class="h4"><?php echo e($daily->transaction ?? ''); ?></strong>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="callout callout-info">
                                        <small class="text-muted">Produk</small>
                                        <br>
                                        <strong class="h4"><?php echo e($daily->active_products ?? ''); ?></strong>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="callout callout-warning">
                                        <small class="text-muted">Pesanan Perlu Diproses</small>
                                        <br>
                                        <strong class="h4"><?php echo e($daily->on_process ?? ''); ?></strong>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="callout callout-warning">
                                        <small class="text-muted">Produk Perlu Restock</small>
                                        <br>
                                        <strong class="h4"><?php echo e($restock_qty ?? ''); ?></strong>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="callout callout-warning">
                                        <small class="text-muted">Pegawai</small>
                                        <br>
                                        <strong class="h4"><?php echo e($employee_total ?? ''); ?></strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Laporan Bulan Ini</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="callout callout-info">
                                        <small class="text-muted">Produk Terjual</small>
                                        <br>
                                        <strong class="h4"><?php echo e($monthly->sold ?? ''); ?></strong>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="callout callout-danger">
                                        <small class="text-muted">Pemasukan</small>
                                        <br>
                                        <strong class="h4"><?php echo e($monthly->income ?? ''); ?></strong>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="callout callout-primary">
                                        <small class="text-muted">Pengeluaran</small>
                                        <br>
                                        <strong class="h4"><?php echo e($monthly->expense ?? ''); ?></strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kalola2\resources\views/business/owner/dashboard.blade.php ENDPATH**/ ?>